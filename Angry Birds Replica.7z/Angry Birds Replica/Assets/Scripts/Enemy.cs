﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    // Variables de clase
    public static int EnemiesAlive = 0;

    // Variables públicas
    // (configurables desde el editor)
    public float hp = 8f;
    public float dmgThreshold = 3f;
    public Sprite dmgSprite;
    public GameObject deathEffect;

    // Use this for initialization
    private void Start()
    {
        // Incrementar la cantidad de enemigos
        EnemiesAlive++;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Calculo del daño
        float dmg = collision.relativeVelocity.magnitude * collision.otherRigidbody.mass;

        // Comprobar si el daño sobrepasa el umbral
        if (dmg > dmgThreshold)
        {
            // Reducir puntos de salud
            hp -= dmg;

            // Va a morir?
            if (hp <= 0)
            {
                Die();
            }

            // Le cambiamos el sprite?
            else if (hp < dmgThreshold)
            {
                GetComponent<SpriteRenderer>().sprite = dmgSprite;
            }
        }
    }

    private void Die()
    {
        // Crear la explosión
        Instantiate(deathEffect, transform.position, Quaternion.identity);

        // Reducir la cantidad de enemigos restantes
        EnemiesAlive--;

        // Comprobar si hay enemigos restantes
        if (EnemiesAlive <= 0)
            Debug.Log("LEVEL WON!");

        // Destruir objeto
        Destroy(gameObject);
    }
}
