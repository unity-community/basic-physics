﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Ball : MonoBehaviour {
    // Variables públicas
    // (configurables desde el editor)
    public Rigidbody2D hook;
    public float maxDragDist = 2f;
    public float releaseTime = .15f;
    public GameObject nextBall;

    // Variables locales
    private Rigidbody2D rb;
    private bool isPressed = false;

    // Use this for initialization
    private void Start ()
    {
        rb = GetComponent<Rigidbody2D>();
    }
	
	// Update is called once per frame
	private void Update ()
    {
        // Obtener la posición del cursor
        Vector2 m = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        if (isPressed)
        {
            // Limitar el movimiento de la bola
            if (Vector2.Distance(hook.position, m) > maxDragDist)
                rb.position = hook.position + (m - hook.position).normalized * maxDragDist;
            else
                rb.position = m;
        }
    }

    // Al clickear...
    private void OnMouseDown()
    {
        isPressed = true;
        rb.isKinematic = true;
    }

    // Al soltar...
    private void OnMouseUp()
    {
        isPressed = false;
        rb.isKinematic = false;
        StartCoroutine(Release());
    }

    // Corrutina,
    // ...coming soon
    IEnumerator Release()
    {
        yield return new WaitForSeconds(releaseTime);
        GetComponent<SpringJoint2D>().enabled = false;
        this.enabled = false;

        yield return new WaitForSeconds(3f);
        if (nextBall != null)
            nextBall.SetActive(true);
        else
        {
            Enemy.EnemiesAlive = 0;
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}
